import type { Config } from "tailwindcss";

const config: Config = {
  content: ["./src/**/*.{ts,tsx}"],
  theme: {
    extend: {
      colors: {
        bg: "#080808",
        surface: "#111111",
        card: "#171717",
        elevated: "#202020",
        brand: "#FF6B00",
        "brand-2": "#FF8C32",
        sub: "#B5B5B5",
        mute: "#777777",
        line: "#303030",
      },
      fontFamily: {
        heading: ["var(--font-space)", "system-ui", "sans-serif"],
        body: ["var(--font-inter)", "system-ui", "sans-serif"],
      },
      boxShadow: {
        glow: "0 0 40px rgba(255,107,0,0.35)",
        "glow-sm": "0 0 24px rgba(255,107,0,0.28)",
      },
    },
  },
  plugins: [],
};
export default config;
