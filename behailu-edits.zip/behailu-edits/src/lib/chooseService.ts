// Lets service and pricing buttons pre-select a service in the inquiry form.
export const SELECT_SERVICE_EVENT = "behailu:select-service";

export function chooseService(service: string) {
  if (typeof window === "undefined") return;
  window.dispatchEvent(new CustomEvent(SELECT_SERVICE_EVENT, { detail: service }));
}
