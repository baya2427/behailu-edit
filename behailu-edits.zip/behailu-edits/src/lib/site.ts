// One place for brand details, contact info and integration settings.
export const site = {
  name: "Behailu.edits",
  title: "Behailu.edits | Short-Form Video Editor for Personal Brands & Creators",
  description:
    "Transform raw footage into engaging Instagram Reels, TikTok videos, and YouTube Shorts. Professional short-form video editing for personal brands, coaches, and creators.",
  url: process.env.NEXT_PUBLIC_SITE_URL || "",
  email: "behailumitiku03@gmail.com",

  // Formspree: set NEXT_PUBLIC_FORMSPREE_ID, or paste the ID between the quotes.
  formspreeId: process.env.NEXT_PUBLIC_FORMSPREE_ID || "",

  // Calendly: your account link. Replace with a specific event link
  // (e.g. https://calendly.com/behailumitiku03/20min) so visitors land on the 20-minute call.
  calendlyUrl: process.env.NEXT_PUBLIC_CALENDLY_URL || "https://calendly.com/behailumitiku03",

  // Your photo for the About section. Put the file at public/images/about.jpg
  aboutPhoto: "/images/about.jpg",

  // Optional hero reel (vertical MP4), e.g. "/videos/hero-reel.mp4". Leave empty for the placeholder.
  heroVideo: "",

  socials: [
    { label: "Instagram", href: "https://instagram.com/behailu.edits" },
    { label: "LinkedIn", href: "https://www.linkedin.com/in/behailu-m-650855313" },
  ],
};
