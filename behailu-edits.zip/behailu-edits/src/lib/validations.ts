import { z } from "zod";

export const serviceOptions = [
  "Monthly Short-Form Editing",
  "Individual Video Editing",
  "Talking-Head Editing",
  "Podcast Repurposing",
  "Personal Brand Content",
  "Other",
];
export const videoCountOptions = ["1–3 videos", "4–8 videos", "9–15 videos", "16+ videos", "Not sure yet"];
export const styleOptions = [
  "Clean and Professional",
  "Fast-Paced and Engaging",
  "Cinematic and Storytelling",
  "Modern Motion Graphics",
  "I have a reference video",
];
export const budgetOptions = ["Under $100", "$100–$300", "$300–$500", "$500–$1,000", "$1,000+", "Not sure yet"];
export const timelineOptions = ["As soon as possible", "Within one week", "Within two weeks", "Flexible timeline"];
export const footageOptions = ["Footage is ready", "Recording is in progress", "I need to discuss the project first"];

export const inquirySchema = z.object({
  fullName: z.string().trim().min(2, "Enter your full name."),
  email: z.string().trim().min(1, "Enter your email address.").email("Enter a valid email address."),
  brand: z.string().trim().max(120, "Keep this under 120 characters.").optional(),
  profileLink: z.string().trim().max(300, "Keep this under 300 characters.").optional(),
  service: z.string().min(1, "Choose the service you need."),
  videoCount: z.string().optional(),
  style: z.string().optional(),
  budget: z.string().optional(),
  timeline: z.string().optional(),
  description: z
    .string()
    .trim()
    .min(20, "Add a little more detail — at least 20 characters.")
    .max(3000, "Keep the description under 3,000 characters."),
  referenceLinks: z.string().trim().max(1000, "Keep this under 1,000 characters.").optional(),
  footage: z.string().optional(),
  // Honeypot: real visitors never fill this in.
  _gotcha: z.string().max(0).optional(),
});

export type InquiryValues = z.infer<typeof inquirySchema>;
