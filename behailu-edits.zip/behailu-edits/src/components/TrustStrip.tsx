const audiences = ["Personal Brands", "Coaches", "Creators", "Podcasts", "Businesses", "Agencies"];

export default function TrustStrip() {
  return (
    <section aria-label="Who I work with" className="border-y border-line bg-surface py-10">
      <div className="mx-auto max-w-6xl px-5 text-center">
        <p className="text-xs font-semibold uppercase tracking-[0.22em] text-mute">
          Built for creators who take content seriously
        </p>
        <ul className="mt-6 flex flex-wrap items-center justify-center gap-x-0 gap-y-3">
          {audiences.map((a, i) => (
            <li key={a} className="flex items-center">
              {i > 0 && <span aria-hidden className="mx-5 h-4 w-px bg-line md:mx-8" />}
              <span className="font-heading text-base font-semibold text-sub md:text-lg">{a}</span>
            </li>
          ))}
        </ul>
      </div>
    </section>
  );
}
