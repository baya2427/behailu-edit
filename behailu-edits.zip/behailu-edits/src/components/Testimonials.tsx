"use client";

import { ChevronLeft, ChevronRight } from "lucide-react";
import { useRef } from "react";
import { testimonials } from "@/data/testimonials";
import Reveal from "./Reveal";
import SectionHeading from "./SectionHeading";

// Hidden until you add real testimonials in src/data/testimonials.ts
export default function Testimonials() {
  const track = useRef<HTMLDivElement>(null);
  if (!testimonials.length) return null;

  const scroll = (dir: 1 | -1) =>
    track.current?.scrollBy({ left: dir * (track.current.clientWidth * 0.9), behavior: "smooth" });

  return (
    <section id="testimonials" className="bg-surface py-24 md:py-32">
      <div className="mx-auto max-w-6xl px-5">
        <Reveal>
          <SectionHeading label="Testimonials" title="What Clients Say" />
        </Reveal>
        <div ref={track} className="no-scrollbar mt-14 flex snap-x snap-mandatory gap-5 overflow-x-auto">
          {testimonials.map((t) => (
            <figure
              key={t.name}
              className="w-full shrink-0 snap-start rounded-xl border border-line bg-card p-8 md:w-[calc(50%-10px)]"
            >
              <blockquote className="text-lg leading-relaxed text-white">“{t.text}”</blockquote>
              <figcaption className="mt-6 flex items-center gap-4">
                {t.image && (
                  // eslint-disable-next-line @next/next/no-img-element
                  <img src={t.image} alt={t.name} loading="lazy" className="h-12 w-12 rounded-full object-cover" />
                )}
                <div>
                  <p className="font-heading font-semibold text-white">{t.name}</p>
                  <p className="text-sm text-sub">{t.role}</p>
                </div>
              </figcaption>
            </figure>
          ))}
        </div>
        {testimonials.length > 1 && (
          <div className="mt-6 flex justify-center gap-3">
            <button type="button" aria-label="Previous testimonial" onClick={() => scroll(-1)} className="flex h-11 w-11 items-center justify-center rounded-full border border-line text-white hover:border-brand hover:text-brand">
              <ChevronLeft size={20} />
            </button>
            <button type="button" aria-label="Next testimonial" onClick={() => scroll(1)} className="flex h-11 w-11 items-center justify-center rounded-full border border-line text-white hover:border-brand hover:text-brand">
              <ChevronRight size={20} />
            </button>
          </div>
        )}
      </div>
    </section>
  );
}
