"use client";

import { AnimatePresence, motion } from "framer-motion";
import { X } from "lucide-react";
import { useEffect, useRef } from "react";
import type { PortfolioItem } from "@/data/portfolio";

type Embed = { kind: "file" | "iframe"; src: string } | null;

function getEmbed(url: string): Embed {
  if (!url) return null;
  const vimeo = url.match(/vimeo\.com\/(?:video\/)?(\d+)(?:\/([a-zA-Z0-9]+))?/);
  if (vimeo) {
    const hash = vimeo[2] ? `&h=${vimeo[2]}` : "";
    return { kind: "iframe", src: `https://player.vimeo.com/video/${vimeo[1]}?autoplay=1${hash}` };
  }
  const yt = url.match(/(?:youtube\.com\/(?:watch\?v=|shorts\/|embed\/)|youtu\.be\/)([\w-]{11})/);
  if (yt) return { kind: "iframe", src: `https://www.youtube-nocookie.com/embed/${yt[1]}?autoplay=1&rel=0` };
  return { kind: "file", src: url };
}

export default function VideoModal({ item, onClose }: { item: PortfolioItem | null; onClose: () => void }) {
  const dialogRef = useRef<HTMLDivElement>(null);
  const closeRef = useRef<HTMLButtonElement>(null);

  useEffect(() => {
    if (!item) return;
    const previouslyFocused = document.activeElement as HTMLElement | null;
    const overflow = document.body.style.overflow;
    document.body.style.overflow = "hidden";
    closeRef.current?.focus();

    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") {
        onClose();
        return;
      }
      if (e.key === "Tab" && dialogRef.current) {
        const focusable = dialogRef.current.querySelectorAll<HTMLElement>(
          'button, [href], video, iframe, [tabindex]:not([tabindex="-1"])'
        );
        if (!focusable.length) return;
        const first = focusable[0];
        const last = focusable[focusable.length - 1];
        if (e.shiftKey && document.activeElement === first) {
          e.preventDefault();
          last.focus();
        } else if (!e.shiftKey && document.activeElement === last) {
          e.preventDefault();
          first.focus();
        }
      }
    };
    window.addEventListener("keydown", onKey);
    return () => {
      window.removeEventListener("keydown", onKey);
      document.body.style.overflow = overflow;
      previouslyFocused?.focus();
    };
  }, [item, onClose]);

  const embed = item ? getEmbed(item.videoUrl) : null;

  return (
    <AnimatePresence>
      {item && (
        <motion.div
          className="fixed inset-0 z-[100] flex items-center justify-center bg-black/85 p-4 backdrop-blur-md"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          transition={{ duration: 0.2 }}
          onClick={onClose}
        >
          <motion.div
            ref={dialogRef}
            role="dialog"
            aria-modal="true"
            aria-label={item.title}
            initial={{ opacity: 0, scale: 0.94, y: 16 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.96, y: 8 }}
            transition={{ duration: 0.25, ease: "easeOut" }}
            onClick={(e) => e.stopPropagation()}
            className="relative flex max-h-full w-full max-w-[440px] flex-col rounded-2xl border border-[rgba(255,107,0,0.35)] bg-surface p-3 shadow-[0_0_80px_rgba(255,107,0,0.2)]"
          >
            <button
              ref={closeRef}
              type="button"
              onClick={onClose}
              aria-label="Close video"
              className="absolute right-3 top-3 z-10 flex h-10 w-10 items-center justify-center rounded-full bg-bg/80 text-white backdrop-blur transition hover:bg-brand hover:text-bg"
            >
              <X size={20} />
            </button>

            <div
              className="relative mx-auto w-full overflow-hidden rounded-xl bg-black"
              style={{ aspectRatio: "9 / 16", maxHeight: "min(74vh, 720px)" }}
            >
              {embed?.kind === "file" && (
                <video
                  key={embed.src}
                  src={embed.src}
                  poster={item.thumbnail || undefined}
                  controls
                  autoPlay
                  playsInline
                  preload="metadata"
                  className="h-full w-full object-contain"
                />
              )}
              {embed?.kind === "iframe" && (
                <iframe
                  src={embed.src}
                  title={item.title}
                  allow="autoplay; fullscreen; picture-in-picture"
                  allowFullScreen
                  className="h-full w-full border-0"
                />
              )}
              {!embed && (
                <div className="flex h-full flex-col items-center justify-center gap-2 px-8 text-center">
                  <p className="font-heading text-lg font-semibold text-white">No video added yet</p>
                  <p className="text-sm text-sub">Add a videoUrl for this item in src/data/portfolio.ts.</p>
                </div>
              )}
            </div>

            <div className="px-2 pb-1 pt-4">
              <p className="font-heading text-lg font-semibold text-white">{item.title}</p>
              {item.description && <p className="mt-1 text-sm text-sub">{item.description}</p>}
            </div>
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}
