"use client";

import { Clapperboard, Podcast, User, Video, type LucideIcon } from "lucide-react";
import { services } from "@/data/services";
import { chooseService } from "@/lib/chooseService";
import Reveal from "./Reveal";
import SectionHeading from "./SectionHeading";

const icons: Record<string, LucideIcon> = { clapperboard: Clapperboard, video: Video, podcast: Podcast, user: User };

export default function Services() {
  return (
    <section id="services" className="py-24 md:py-32">
      <div className="mx-auto max-w-6xl px-5">
        <Reveal>
          <SectionHeading
            label="Services"
            title="What I Do"
            subtitle="Short-form editing solutions designed for creators and brands that want better content."
          />
        </Reveal>
        <div className="mt-14 grid gap-5 sm:grid-cols-2 lg:grid-cols-4">
          {services.map((s, i) => {
            const Icon = icons[s.icon];
            return (
              <Reveal key={s.title} delay={i * 0.08} className="h-full">
                <article className="group flex h-full flex-col rounded-lg border border-line bg-card p-6 transition duration-300 hover:-translate-y-1 hover:border-[rgba(255,107,0,0.35)] hover:shadow-glow-sm">
                  <span className="flex h-11 w-11 items-center justify-center rounded-md border border-line bg-elevated text-brand transition group-hover:border-brand">
                    <Icon size={20} />
                  </span>
                  <h3 className="mt-6 font-heading text-xl font-semibold text-white">{s.title}</h3>
                  <p className="mt-3 flex-1 text-sm leading-relaxed text-sub">{s.description}</p>
                  <a
                    href="#contact"
                    onClick={() => chooseService(s.service)}
                    className="mt-6 text-sm font-medium text-brand transition hover:text-brand-2"
                  >
                    Learn more ↗
                  </a>
                </article>
              </Reveal>
            );
          })}
        </div>
      </div>
    </section>
  );
}
