"use client";

import { zodResolver } from "@hookform/resolvers/zod";
import { CheckCircle2, Loader2 } from "lucide-react";
import { useEffect, useState, type ReactNode } from "react";
import { useForm } from "react-hook-form";
import { SELECT_SERVICE_EVENT } from "@/lib/chooseService";
import { site } from "@/lib/site";
import {
  budgetOptions,
  footageOptions,
  inquirySchema,
  serviceOptions,
  styleOptions,
  timelineOptions,
  videoCountOptions,
  type InquiryValues,
} from "@/lib/validations";
import Reveal from "./Reveal";
import SectionHeading from "./SectionHeading";

const input =
  "w-full rounded-md border border-line bg-bg px-4 py-3 text-sm text-white placeholder:text-mute transition focus:border-brand focus:outline-none focus:ring-2 focus:ring-brand/30 aria-[invalid=true]:border-red-400";

function Field({ id, label, required, error, children }: { id: string; label: string; required?: boolean; error?: string; children: ReactNode }) {
  return (
    <div>
      <label htmlFor={id} className="mb-2 block text-sm font-medium text-white">
        {label} {required && <span className="text-brand" aria-hidden>*</span>}
      </label>
      {children}
      {error && (
        <p id={`${id}-error`} role="alert" className="mt-1.5 text-xs text-red-400">
          {error}
        </p>
      )}
    </div>
  );
}

function Select({ id, options, error, ...rest }: { id: string; options: string[]; error?: string } & React.SelectHTMLAttributes<HTMLSelectElement>) {
  return (
    <select id={id} className={input} aria-invalid={!!error} aria-describedby={error ? `${id}-error` : undefined} {...rest}>
      <option value="">Select an option</option>
      {options.map((o) => (
        <option key={o} value={o}>
          {o}
        </option>
      ))}
    </select>
  );
}

export default function BookingForm() {
  const [status, setStatus] = useState<"idle" | "success">("idle");
  const [serverError, setServerError] = useState<string | null>(null);

  const {
    register,
    handleSubmit,
    setValue,
    reset,
    formState: { errors, isSubmitting },
  } = useForm<InquiryValues>({
    resolver: zodResolver(inquirySchema),
    defaultValues: {
      fullName: "", email: "", brand: "", profileLink: "", service: "", videoCount: "", style: "",
      budget: "", timeline: "", description: "", referenceLinks: "", footage: "", _gotcha: "",
    },
  });

  // Service and pricing buttons pre-select the matching option.
  useEffect(() => {
    const handler = (e: Event) => {
      const service = (e as CustomEvent<string>).detail;
      if (serviceOptions.includes(service)) setValue("service", service, { shouldValidate: true });
    };
    window.addEventListener(SELECT_SERVICE_EVENT, handler);
    return () => window.removeEventListener(SELECT_SERVICE_EVENT, handler);
  }, [setValue]);

  const onSubmit = async (v: InquiryValues) => {
    setServerError(null);
    if (!site.formspreeId) {
      setServerError(
        `The form isn’t connected yet, so nothing was sent. Please email ${site.email} directly.`
      );
      return;
    }
    try {
      const res = await fetch(`https://formspree.io/f/${site.formspreeId}`, {
        method: "POST",
        headers: { "Content-Type": "application/json", Accept: "application/json" },
        body: JSON.stringify({
          _subject: `New project inquiry from ${v.fullName}`,
          "Full name": v.fullName,
          Email: v.email,
          "Company / brand": v.brand,
          "Website or social profile": v.profileLink,
          Service: v.service,
          "Number of videos": v.videoCount,
          "Editing style": v.style,
          Budget: v.budget,
          Timeline: v.timeline,
          "Project description": v.description,
          "Reference links": v.referenceLinks,
          "Footage status": v.footage,
          _gotcha: v._gotcha,
        }),
      });
      if (res.ok) {
        setStatus("success");
        return;
      }
      const data = await res.json().catch(() => null);
      const msg = data?.errors?.map((e: { message: string }) => e.message).join(" ");
      setServerError(msg || `Your inquiry wasn’t sent. Try again, or email ${site.email}.`);
    } catch {
      setServerError(`Couldn’t reach the server. Check your connection and try again, or email ${site.email}.`);
    }
  };

  return (
    <section id="contact" className="relative overflow-hidden py-24 md:py-32">
      <div className="relative mx-auto max-w-3xl px-5">
        <Reveal>
          <SectionHeading
            label="Project inquiry"
            title="Let’s Bring Your Next Video Project to Life."
            subtitle="Tell me about your content, your goals, and what you need. I’ll review your requirements and we can discuss how to move forward."
          />
        </Reveal>

        <Reveal delay={0.1}>
          <div className="mt-12 rounded-2xl border border-line bg-card p-6 sm:p-9">
            {status === "success" ? (
              <div role="status" className="py-8 text-center">
                <CheckCircle2 className="mx-auto text-brand" size={48} />
                <h3 className="mt-5 font-heading text-2xl font-bold text-white">Inquiry sent</h3>
                <p className="mx-auto mt-3 max-w-md text-sub">
                  Thanks for the details. Next, book a 20-minute discovery call so we can talk through your project.
                </p>
                <div className="mt-7 flex flex-col items-center justify-center gap-3 sm:flex-row">
                  <a href="#booking" className="rounded-md bg-brand px-7 py-3.5 text-sm font-semibold tracking-wide text-bg transition hover:bg-brand-2">
                    BOOK A DISCOVERY CALL ↗
                  </a>
                  <button
                    type="button"
                    onClick={() => {
                      reset();
                      setStatus("idle");
                    }}
                    className="rounded-md border border-line px-7 py-3.5 text-sm font-semibold text-white transition hover:border-brand hover:text-brand"
                  >
                    SEND ANOTHER INQUIRY
                  </button>
                </div>
              </div>
            ) : (
              <form onSubmit={handleSubmit(onSubmit)} noValidate className="space-y-6">
                <div className="grid gap-6 sm:grid-cols-2">
                  <Field id="fullName" label="Full name" required error={errors.fullName?.message}>
                    <input id="fullName" autoComplete="name" className={input} aria-invalid={!!errors.fullName} aria-describedby={errors.fullName ? "fullName-error" : undefined} {...register("fullName")} />
                  </Field>
                  <Field id="email" label="Email address" required error={errors.email?.message}>
                    <input id="email" type="email" autoComplete="email" className={input} aria-invalid={!!errors.email} aria-describedby={errors.email ? "email-error" : undefined} {...register("email")} />
                  </Field>
                  <Field id="brand" label="Company / brand name" error={errors.brand?.message}>
                    <input id="brand" autoComplete="organization" className={input} {...register("brand")} />
                  </Field>
                  <Field id="profileLink" label="Website or social media profile" error={errors.profileLink?.message}>
                    <input id="profileLink" className={input} placeholder="https://instagram.com/yourname" {...register("profileLink")} />
                  </Field>
                  <Field id="service" label="What service are you interested in?" required error={errors.service?.message}>
                    <Select id="service" options={serviceOptions} error={errors.service?.message} {...register("service")} />
                  </Field>
                  <Field id="videoCount" label="How many videos do you need?">
                    <Select id="videoCount" options={videoCountOptions} {...register("videoCount")} />
                  </Field>
                  <Field id="style" label="Preferred editing style">
                    <Select id="style" options={styleOptions} {...register("style")} />
                  </Field>
                  <Field id="budget" label="Approximate budget">
                    <Select id="budget" options={budgetOptions} {...register("budget")} />
                  </Field>
                  <Field id="timeline" label="When do you need the videos?">
                    <Select id="timeline" options={timelineOptions} {...register("timeline")} />
                  </Field>
                </div>

                <Field id="description" label="Project description" required error={errors.description?.message}>
                  <textarea id="description" rows={5} className={input} placeholder="What kind of content do you make, and what should these videos achieve?" aria-invalid={!!errors.description} aria-describedby={errors.description ? "description-error" : undefined} {...register("description")} />
                </Field>

                <Field id="referenceLinks" label="Reference video links" error={errors.referenceLinks?.message}>
                  <textarea id="referenceLinks" rows={3} className={input} placeholder="Paste links to edits you like, one per line." {...register("referenceLinks")} />
                </Field>

                <fieldset>
                  <legend className="mb-3 text-sm font-medium text-white">Footage status</legend>
                  <div className="grid gap-3 sm:grid-cols-3">
                    {footageOptions.map((o) => (
                      <label key={o} className="flex cursor-pointer items-center gap-3 rounded-md border border-line bg-bg px-4 py-3 text-sm text-sub transition has-[:checked]:border-brand has-[:checked]:text-white hover:border-brand/60">
                        <input type="radio" value={o} className="h-4 w-4 accent-[#FF6B00]" {...register("footage")} />
                        {o}
                      </label>
                    ))}
                  </div>
                </fieldset>

                {/* Honeypot for spam bots. Humans never see this. */}
                <div aria-hidden className="absolute -left-[9999px] h-0 w-0 overflow-hidden">
                  <label>
                    Leave this empty
                    <input tabIndex={-1} autoComplete="off" {...register("_gotcha")} />
                  </label>
                </div>

                {serverError && (
                  <p role="alert" className="rounded-md border border-red-400/40 bg-red-400/10 px-4 py-3 text-sm text-red-300">
                    {serverError}
                  </p>
                )}

                <button
                  type="submit"
                  disabled={isSubmitting}
                  className="flex w-full items-center justify-center gap-2 rounded-md bg-brand px-7 py-4 text-sm font-semibold tracking-wide text-bg transition hover:bg-brand-2 hover:shadow-glow-sm disabled:cursor-not-allowed disabled:opacity-70"
                >
                  {isSubmitting ? (
                    <>
                      <Loader2 size={18} className="animate-spin" /> SENDING…
                    </>
                  ) : (
                    "SUBMIT PROJECT INQUIRY ↗"
                  )}
                </button>
                <p className="text-center text-xs text-mute">Fields marked * are required.</p>
              </form>
            )}
          </div>
        </Reveal>
      </div>
    </section>
  );
}
