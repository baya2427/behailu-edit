"use client";

import { motion, useReducedMotion } from "framer-motion";
import SectionHeading from "./SectionHeading";
import Reveal from "./Reveal";

const steps = [
  { title: "Discovery & Strategy", text: "We discuss your content goals, audience, preferred editing style, video requirements, and deadlines." },
  { title: "Creative Editing", text: "I transform your footage through strategic cuts, captions, pacing, sound design, and visual storytelling." },
  { title: "Review & Revisions", text: "You review the first version and provide feedback. I make the agreed revisions to bring the video closer to your expectations." },
  { title: "Final Delivery", text: "Your finished videos are delivered in the agreed formats, ready for your social media platforms." },
];

export default function Process() {
  const reduce = useReducedMotion();
  const grow = (axis: "x" | "y") => ({
    initial: reduce ? false : axis === "x" ? { scaleX: 0 } : { scaleY: 0 },
    whileInView: axis === "x" ? { scaleX: 1 } : { scaleY: 1 },
    viewport: { once: true, margin: "-120px" },
    transition: { duration: 1.6, ease: "easeInOut" as const },
  });

  return (
    <section id="process" className="relative overflow-hidden bg-surface py-24 md:py-32">
      <div aria-hidden className="pointer-events-none absolute left-1/2 top-0 h-72 w-[800px] -translate-x-1/2 rounded-full bg-[radial-gradient(ellipse,rgba(255,107,0,0.18),transparent_70%)] blur-3xl" />
      <div className="relative mx-auto max-w-6xl px-5">
        <Reveal>
          <SectionHeading label="Working process" title="From Raw Footage to Ready-to-Publish Content." />
        </Reveal>

        <ol className="relative mt-16 grid gap-10 lg:grid-cols-4 lg:gap-8">
          <div aria-hidden className="absolute bottom-2 left-[11px] top-2 w-px bg-line lg:hidden">
            <motion.div {...grow("y")} className="h-full w-full origin-top bg-brand" />
          </div>
          <div aria-hidden className="absolute left-0 right-0 top-[11px] hidden h-px bg-line lg:block">
            <motion.div {...grow("x")} className="h-full w-full origin-left bg-brand" />
          </div>

          {steps.map((s, i) => (
            <li key={s.title} className="relative pl-10 lg:pl-0 lg:pt-12">
              <span className="absolute left-0 top-0 flex h-6 w-6 items-center justify-center rounded-full border border-brand bg-bg shadow-glow-sm">
                <span className="h-2 w-2 rounded-full bg-brand" />
              </span>
              <p className="font-heading text-sm font-semibold text-brand">Step 0{i + 1}</p>
              <h3 className="mt-2 font-heading text-xl font-semibold text-white">{s.title}</h3>
              <p className="mt-3 text-sm leading-relaxed text-sub">{s.text}</p>
            </li>
          ))}
        </ol>
      </div>
    </section>
  );
}
