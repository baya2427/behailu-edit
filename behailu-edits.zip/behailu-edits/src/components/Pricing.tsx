"use client";

import { Check } from "lucide-react";
import { plans } from "@/data/pricing";
import { chooseService } from "@/lib/chooseService";
import Reveal from "./Reveal";
import SectionHeading from "./SectionHeading";

export default function Pricing() {
  return (
    <section id="pricing" className="relative overflow-hidden py-24 md:py-32">
      <div aria-hidden className="pointer-events-none absolute left-1/2 top-1/2 h-[620px] w-[900px] -translate-x-1/2 -translate-y-1/2 rounded-full bg-[radial-gradient(ellipse,rgba(255,107,0,0.22),transparent_68%)] blur-3xl" />
      <div className="relative mx-auto max-w-6xl px-5">
        <Reveal>
          <SectionHeading
            label="Pricing"
            title="Choose the Right Editing Plan."
            subtitle="Flexible editing solutions for creators and brands at different stages."
          />
        </Reveal>

        <div className="mt-16 grid items-stretch gap-6 lg:grid-cols-3">
          {plans.map((p, i) => (
            <Reveal key={p.name} delay={i * 0.1} className="h-full">
              <article
                className={`relative flex h-full flex-col rounded-xl border p-7 ${
                  p.highlighted
                    ? "border-brand bg-elevated shadow-glow lg:-my-3 lg:py-10"
                    : "border-line bg-card"
                }`}
              >
                {p.highlighted && (
                  <span className="absolute -top-3 left-7 rounded bg-brand px-3 py-1 text-xs font-semibold text-bg">
                    Recommended
                  </span>
                )}
                <h3 className="font-heading text-2xl font-bold text-white">{p.name}</h3>
                <p className="mt-2 min-h-[48px] text-sm leading-relaxed text-sub">{p.tagline}</p>
                <p className="mt-6 font-heading text-3xl font-bold text-white">{p.price}</p>
                <ul className="mt-6 flex-1 space-y-3">
                  {p.features.map((f) => (
                    <li key={f} className="flex gap-3 text-sm text-sub">
                      <Check size={18} className="mt-0.5 shrink-0 text-brand" />
                      <span>{f}</span>
                    </li>
                  ))}
                </ul>
                <a
                  href="#contact"
                  onClick={() => chooseService(p.service)}
                  className={`mt-8 block rounded-md px-5 py-3.5 text-center text-sm font-semibold tracking-wide transition ${
                    p.highlighted
                      ? "bg-brand text-bg hover:bg-brand-2 hover:shadow-glow-sm"
                      : "border border-line text-white hover:border-brand hover:text-brand"
                  }`}
                >
                  {p.button}
                </a>
              </article>
            </Reveal>
          ))}
        </div>
      </div>
    </section>
  );
}
