"use client";

import { motion, useReducedMotion } from "framer-motion";
import { Layers, Music2, Play, Scissors, Type } from "lucide-react";
import { site } from "@/lib/site";

function EditorShowcase() {
  return (
    <div className="relative mx-auto mt-16 w-full max-w-4xl px-5 md:mt-20">
      {/* glow behind the window */}
      <div aria-hidden className="absolute inset-x-10 -bottom-10 top-10 rounded-full bg-brand/25 blur-[90px]" />

      <div className="relative overflow-hidden rounded-xl border border-[rgba(255,107,0,0.35)] bg-surface shadow-[0_0_80px_rgba(255,107,0,0.18)]">
        {/* window bar */}
        <div className="flex items-center gap-2 border-b border-line bg-card px-4 py-3">
          <span className="h-2.5 w-2.5 rounded-full bg-[#FF5F57]" />
          <span className="h-2.5 w-2.5 rounded-full bg-[#FEBC2E]" />
          <span className="h-2.5 w-2.5 rounded-full bg-[#28C840]" />
          <span className="ml-3 truncate text-xs text-mute">Your reel · 9:16 · 30 fps</span>
        </div>

        {/* workspace */}
        <div className="grid grid-cols-[44px_1fr] md:grid-cols-[52px_1fr_220px]">
          <div className="flex flex-col items-center gap-5 border-r border-line bg-card/60 py-5 text-sub" aria-hidden>
            <Scissors size={18} />
            <Type size={18} />
            <Music2 size={18} />
            <Layers size={18} />
          </div>

          {/* preview */}
          <div className="relative flex items-center justify-center bg-bg px-4 py-8">
            <div className="relative aspect-[9/16] w-[170px] overflow-hidden rounded-[14px] border border-line bg-gradient-to-b from-elevated via-card to-bg sm:w-[190px]">
              {site.heroVideo ? (
                <video
                  src={site.heroVideo}
                  className="h-full w-full object-cover"
                  autoPlay
                  muted
                  loop
                  playsInline
                  aria-label="Showreel preview"
                />
              ) : (
                <>
                  <div aria-hidden className="absolute -top-8 left-1/2 h-40 w-40 -translate-x-1/2 rounded-full bg-brand/30 blur-3xl" />
                  <div className="absolute inset-0 flex items-center justify-center">
                    <span className="flex h-12 w-12 items-center justify-center rounded-full border border-brand/60 bg-bg/60 text-brand">
                      <Play size={18} fill="currentColor" />
                    </span>
                  </div>
                  <p className="absolute inset-x-3 top-4 text-center text-[10px] text-mute">Your footage goes here</p>
                </>
              )}
              {/* caption preview */}
              <div className="absolute inset-x-3 bottom-8 text-center font-heading text-lg font-bold leading-tight text-white drop-shadow">
                STOP <span className="rounded bg-brand px-1 text-bg">SCROLLING</span>
                <br />
                START WATCHING
              </div>
            </div>
          </div>

          {/* side panel */}
          <div className="hidden flex-col gap-3 border-l border-line bg-card/60 p-4 text-xs md:flex" aria-hidden>
            <p className="text-mute">Edit notes</p>
            {[
              ["Hook", "0:00 – 0:03"],
              ["Captions", "Word-by-word"],
              ["Sound design", "Layered"],
              ["B-roll", "Placed on beats"],
            ].map(([k, v]) => (
              <div key={k} className="flex items-center justify-between rounded-md border border-line bg-surface px-3 py-2.5">
                <span className="text-white">{k}</span>
                <span className="text-sub">{v}</span>
              </div>
            ))}
          </div>
        </div>

        {/* timeline */}
        <div className="relative border-t border-line bg-card/60 px-4 py-4" aria-hidden>
          <div className="space-y-2">
            <div className="flex gap-1.5">
              {[18, 12, 22, 14, 20, 14].map((w, i) => (
                <div key={i} className="h-5 rounded-sm bg-brand/80" style={{ flexGrow: w }} />
              ))}
            </div>
            <div className="flex gap-1.5">
              {[10, 8, 14, 9, 12, 8, 10].map((w, i) => (
                <div key={i} className="h-3.5 rounded-sm border border-line bg-elevated" style={{ flexGrow: w }} />
              ))}
            </div>
            <div className="flex h-5 items-center gap-[3px]">
              {Array.from({ length: 56 }).map((_, i) => (
                <span
                  key={i}
                  className="w-full rounded-full bg-brand-2/50"
                  style={{ height: `${25 + Math.abs(Math.sin(i * 1.7)) * 75}%` }}
                />
              ))}
            </div>
          </div>
          <div className="playhead absolute bottom-3 top-3 w-px bg-white">
            <span className="absolute -top-1 left-1/2 h-2 w-2 -translate-x-1/2 rotate-45 bg-white" />
          </div>
        </div>
      </div>
    </div>
  );
}

export default function Hero() {
  const reduce = useReducedMotion();
  const fade = (delay: number) => ({
    initial: reduce ? false : { opacity: 0, y: 22 },
    animate: { opacity: 1, y: 0 },
    transition: { duration: 0.8, delay, ease: [0.22, 1, 0.36, 1] as const },
  });

  return (
    <section id="home" className="relative overflow-hidden pb-24 pt-36 md:pt-44">
      {/* cinematic orange ambient light */}
      <div aria-hidden className="pointer-events-none absolute inset-0">
        <div className="absolute left-1/2 top-[-18%] h-[760px] w-[760px] -translate-x-1/2 rounded-full bg-[radial-gradient(circle,rgba(255,107,0,0.55)_0%,rgba(255,70,0,0.22)_40%,transparent_70%)] blur-3xl" />
        <div className="absolute left-1/2 top-[6%] h-[620px] w-[620px] -translate-x-1/2 rounded-full border border-[rgba(255,107,0,0.35)] opacity-60 blur-[2px]" />
        <div className="absolute -left-40 top-1/3 h-[420px] w-[420px] rounded-full bg-[radial-gradient(circle,rgba(255,107,0,0.28),transparent_70%)] blur-3xl" />
        <div className="absolute -right-40 top-1/4 h-[420px] w-[420px] rounded-full bg-[radial-gradient(circle,rgba(255,70,0,0.22),transparent_70%)] blur-3xl" />
        <div className="absolute inset-x-0 bottom-0 h-40 bg-gradient-to-t from-bg to-transparent" />
      </div>

      <div className="relative mx-auto max-w-4xl px-5 text-center">
        <motion.p
          {...fade(0)}
          className="mb-6 inline-block rounded-full border border-[rgba(255,107,0,0.35)] bg-bg/50 px-4 py-1.5 text-xs font-semibold uppercase tracking-[0.22em] text-brand-2 backdrop-blur"
        >
          Short-form video editor
        </motion.p>
        <motion.h1
          {...fade(0.08)}
          className="font-heading text-4xl font-bold leading-[1.05] tracking-tight text-white sm:text-5xl md:text-6xl lg:text-7xl"
        >
          I Don’t Just Edit Videos — I Edit for Attention.
        </motion.h1>
        <motion.p {...fade(0.16)} className="mx-auto mt-6 max-w-2xl text-base leading-relaxed text-sub md:text-lg">
          I help personal brands, coaches, and creators turn raw footage into engaging short-form content that captures
          attention, keeps viewers watching, and makes every second count.
        </motion.p>
        <motion.div {...fade(0.24)} className="mt-9 flex flex-col items-center justify-center gap-3 sm:flex-row">
          <a
            href="#booking"
            className="w-full rounded-md bg-brand px-7 py-3.5 text-sm font-semibold tracking-wide text-bg transition hover:bg-brand-2 hover:shadow-glow-sm sm:w-auto"
          >
            BOOK A PROJECT CALL ↗
          </a>
          <a
            href="#work"
            className="w-full rounded-md border border-line bg-bg/40 px-7 py-3.5 text-sm font-semibold tracking-wide text-white backdrop-blur transition hover:border-brand hover:text-brand sm:w-auto"
          >
            EXPLORE MY WORK
          </a>
        </motion.div>
      </div>

      <motion.div {...fade(0.36)} className="relative">
        <EditorShowcase />
      </motion.div>
    </section>
  );
}
