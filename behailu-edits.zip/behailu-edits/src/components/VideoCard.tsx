"use client";

import { Film, Play } from "lucide-react";
import { useState } from "react";
import type { PortfolioItem } from "@/data/portfolio";

export default function VideoCard({
  item,
  categoryLabel,
  onOpen,
}: {
  item: PortfolioItem;
  categoryLabel: string;
  onOpen: (item: PortfolioItem) => void;
}) {
  const [imgFailed, setImgFailed] = useState(false);
  const showImage = item.thumbnail && !imgFailed;

  return (
    <button
      type="button"
      onClick={() => onOpen(item)}
      aria-label={`Play video: ${item.title}`}
      className="group relative aspect-[9/16] w-[240px] shrink-0 snap-start select-none overflow-hidden rounded-[14px] border border-line bg-card text-left transition duration-300 hover:border-[rgba(255,107,0,0.35)] hover:shadow-glow-sm md:max-lg:w-[220px]"
    >
      {showImage ? (
        // eslint-disable-next-line @next/next/no-img-element
        <img
          src={item.thumbnail}
          alt={item.title}
          width={540}
          height={960}
          loading="lazy"
          decoding="async"
          draggable={false}
          onError={() => setImgFailed(true)}
          className="h-full w-full object-cover transition duration-500 group-hover:scale-[1.03]"
        />
      ) : (
        <div className="flex h-full w-full flex-col items-center justify-center gap-3 bg-gradient-to-b from-elevated to-card px-4 text-center">
          <Film size={26} className="text-mute" />
          <span className="text-xs text-mute">Add your video</span>
        </div>
      )}

      <div aria-hidden className="absolute inset-0 bg-gradient-to-t from-bg/90 via-bg/10 to-transparent" />

      {item.featured && (
        <span className="absolute left-3 top-3 rounded bg-brand px-2 py-0.5 text-[10px] font-semibold text-bg">
          Featured
        </span>
      )}

      <span
        aria-hidden
        className="absolute left-1/2 top-1/2 flex h-12 w-12 -translate-x-1/2 -translate-y-1/2 items-center justify-center rounded-full border border-white/40 bg-bg/50 text-white backdrop-blur transition duration-300 group-hover:border-brand group-hover:bg-brand group-hover:text-bg"
      >
        <Play size={18} fill="currentColor" className="ml-0.5" />
      </span>

      <div className="absolute inset-x-0 bottom-0 p-4">
        <p className="text-[11px] text-brand-2">{categoryLabel}</p>
        <p className="mt-1 font-heading text-base font-semibold leading-snug text-white">{item.title}</p>
      </div>
    </button>
  );
}
