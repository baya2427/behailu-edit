"use client";

import { useCallback, useState } from "react";
import { categories, portfolio, type PortfolioItem } from "@/data/portfolio";
import PortfolioCarousel from "./PortfolioCarousel";
import Reveal from "./Reveal";
import SectionHeading from "./SectionHeading";
import VideoModal from "./VideoModal";

export default function Portfolio() {
  const [active, setActive] = useState<PortfolioItem | null>(null);
  const close = useCallback(() => setActive(null), []);

  return (
    <section id="work" className="relative bg-surface py-24 md:py-32">
      <div className="mx-auto max-w-6xl px-5">
        <Reveal>
          <SectionHeading
            label="Portfolio"
            title="Selected Work"
            subtitle="Every edit has a purpose. Explore a selection of short-form content designed to capture attention."
          />
        </Reveal>

        <div className="mt-16 space-y-16 md:space-y-20">
          {categories.map((category) => {
            const items = portfolio.filter((p) => p.category === category.id);
            if (!items.length) return null;
            return (
              <Reveal key={category.id}>
                <PortfolioCarousel category={category} items={items} onOpen={setActive} />
              </Reveal>
            );
          })}
        </div>
      </div>
      <VideoModal item={active} onClose={close} />
    </section>
  );
}
