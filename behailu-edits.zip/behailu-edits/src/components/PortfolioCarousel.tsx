"use client";

import { ChevronLeft, ChevronRight } from "lucide-react";
import { useCallback, useEffect, useRef, useState } from "react";
import type { PortfolioCategory, PortfolioItem } from "@/data/portfolio";
import VideoCard from "./VideoCard";

export default function PortfolioCarousel({
  category,
  items,
  onOpen,
}: {
  category: PortfolioCategory;
  items: PortfolioItem[];
  onOpen: (item: PortfolioItem) => void;
}) {
  const trackRef = useRef<HTMLDivElement>(null);
  const drag = useRef({ active: false, startX: 0, startScroll: 0, moved: false });
  const [dragging, setDragging] = useState(false);
  const [canPrev, setCanPrev] = useState(false);
  const [canNext, setCanNext] = useState(true);

  const update = useCallback(() => {
    const el = trackRef.current;
    if (!el) return;
    setCanPrev(el.scrollLeft > 4);
    setCanNext(el.scrollLeft + el.clientWidth < el.scrollWidth - 4);
  }, []);

  useEffect(() => {
    update();
    const el = trackRef.current;
    if (!el) return;
    el.addEventListener("scroll", update, { passive: true });
    window.addEventListener("resize", update);
    return () => {
      el.removeEventListener("scroll", update);
      window.removeEventListener("resize", update);
    };
  }, [update]);

  const scrollByDir = (dir: 1 | -1) => {
    const el = trackRef.current;
    if (!el) return;
    const reduce = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
    el.scrollBy({ left: dir * el.clientWidth * 0.85, behavior: reduce ? "auto" : "smooth" });
  };

  // Mouse drag (touch and trackpad use native scrolling)
  const onMouseDown = (e: React.MouseEvent) => {
    const el = trackRef.current;
    if (!el || e.button !== 0) return;
    drag.current = { active: true, startX: e.clientX, startScroll: el.scrollLeft, moved: false };

    const move = (ev: MouseEvent) => {
      const dx = ev.clientX - drag.current.startX;
      if (!drag.current.moved && Math.abs(dx) > 5) {
        drag.current.moved = true;
        setDragging(true);
      }
      if (drag.current.moved) el.scrollLeft = drag.current.startScroll - dx;
    };
    const up = () => {
      drag.current.active = false;
      setDragging(false);
      window.removeEventListener("mousemove", move);
      window.removeEventListener("mouseup", up);
    };
    window.addEventListener("mousemove", move);
    window.addEventListener("mouseup", up);
  };

  // Stop a drag from being treated as a click on a card
  const onClickCapture = (e: React.MouseEvent) => {
    if (drag.current.moved) {
      e.preventDefault();
      e.stopPropagation();
      drag.current.moved = false;
    }
  };

  const onKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === "ArrowRight") {
      e.preventDefault();
      scrollByDir(1);
    } else if (e.key === "ArrowLeft") {
      e.preventDefault();
      scrollByDir(-1);
    }
  };

  const arrow =
    "flex h-11 w-11 items-center justify-center rounded-full border border-line bg-card text-white transition hover:border-brand hover:text-brand disabled:cursor-not-allowed disabled:opacity-30 disabled:hover:border-line disabled:hover:text-white";

  return (
    <div className="grid gap-6 lg:grid-cols-[260px_minmax(0,1fr)] lg:gap-10">
      <div className="flex items-end justify-between gap-4 lg:block">
        <div>
          <h3 className="font-heading text-2xl font-bold text-white md:text-3xl">{category.title}</h3>
          <p className="mt-2 max-w-xs text-sm leading-relaxed text-sub">{category.description}</p>
        </div>
        <div className="flex shrink-0 gap-2.5 lg:mt-8">
          <button type="button" className={arrow} onClick={() => scrollByDir(-1)} disabled={!canPrev} aria-label={`Scroll ${category.title} backward`}>
            <ChevronLeft size={20} />
          </button>
          <button type="button" className={arrow} onClick={() => scrollByDir(1)} disabled={!canNext} aria-label={`Scroll ${category.title} forward`}>
            <ChevronRight size={20} />
          </button>
        </div>
      </div>

      <div
        ref={trackRef}
        role="region"
        aria-label={`${category.title} videos. Use left and right arrow keys to scroll.`}
        tabIndex={0}
        onKeyDown={onKeyDown}
        onMouseDown={onMouseDown}
        onClickCapture={onClickCapture}
        className={`no-scrollbar flex gap-[14px] overflow-x-auto overscroll-x-contain rounded-[14px] pb-2 md:gap-5 ${
          dragging ? "cursor-grabbing snap-none" : "cursor-grab snap-x snap-proximity"
        }`}
      >
        {items.map((item) => (
          <VideoCard key={item.id} item={item} categoryLabel={category.title} onOpen={onOpen} />
        ))}
      </div>
    </div>
  );
}
