import type { ReactNode } from "react";

export default function LegalPage({ title, children }: { title: string; children: ReactNode }) {
  return (
    <main className="mx-auto max-w-2xl px-5 py-24">
      <a href="/" className="text-sm text-brand hover:text-brand-2">← Back to Behailu.edits</a>
      <h1 className="mt-8 font-heading text-4xl font-bold text-white">{title}</h1>
      <div className="mt-8 space-y-5 leading-relaxed text-sub">{children}</div>
    </main>
  );
}
