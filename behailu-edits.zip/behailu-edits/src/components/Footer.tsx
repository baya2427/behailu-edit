import { Instagram, Linkedin, Mail } from "lucide-react";
import { site } from "@/lib/site";

const nav = [
  { label: "Home", href: "#home" },
  { label: "About", href: "#about" },
  { label: "Work", href: "#work" },
  { label: "Services", href: "#services" },
  { label: "Book a Call", href: "#booking" },
];

const socialIcons: Record<string, typeof Instagram> = { Instagram, LinkedIn: Linkedin };

export default function Footer() {
  return (
    <footer className="border-t border-line bg-surface">
      <div className="mx-auto grid max-w-6xl gap-10 px-5 py-14 md:grid-cols-[1.4fr_1fr_1fr]">
        <div>
          <p className="font-heading text-2xl font-bold text-white">
            Behailu<span className="text-brand">.edits</span>
          </p>
          <p className="mt-3 max-w-xs text-sm leading-relaxed text-sub">
            Short-form video editing for personal brands, coaches, creators, and businesses.
          </p>
        </div>

        <nav aria-label="Footer">
          <ul className="space-y-3 text-sm">
            {nav.map((n) => (
              <li key={n.label}>
                <a href={n.href} className="text-sub transition hover:text-brand">
                  {n.label}
                </a>
              </li>
            ))}
          </ul>
        </nav>

        <div className="space-y-4 text-sm">
          <ul className="flex gap-3">
            {site.socials.map((s) => {
              const Icon = socialIcons[s.label] ?? Mail;
              return (
                <li key={s.label}>
                  <a
                    href={s.href}
                    target="_blank"
                    rel="noopener noreferrer"
                    aria-label={s.label}
                    className="flex h-10 w-10 items-center justify-center rounded-md border border-line text-sub transition hover:border-brand hover:text-brand"
                  >
                    <Icon size={18} />
                  </a>
                </li>
              );
            })}
          </ul>
          <a href={`mailto:${site.email}`} className="block text-sub transition hover:text-brand">
            {site.email}
          </a>
        </div>
      </div>

      <div className="border-t border-line">
        <div className="mx-auto flex max-w-6xl flex-col items-center justify-between gap-3 px-5 py-6 text-xs text-mute sm:flex-row">
          <p>© {new Date().getFullYear()} {site.name}. All rights reserved.</p>
          <div className="flex gap-5">
            <a href="/privacy" className="hover:text-brand">Privacy Policy</a>
            <a href="/terms" className="hover:text-brand">Terms of Service</a>
          </div>
        </div>
      </div>
    </footer>
  );
}
