import Reveal from "./Reveal";

export default function FinalCTA() {
  return (
    <section aria-labelledby="final-cta" className="relative overflow-hidden py-28 md:py-40">
      <div aria-hidden className="pointer-events-none absolute inset-0">
        <div className="absolute left-1/2 top-1/2 h-[720px] w-[720px] -translate-x-1/2 -translate-y-1/2 rounded-full bg-[radial-gradient(circle,rgba(255,107,0,0.6),rgba(255,70,0,0.18)_45%,transparent_70%)] blur-3xl" />
        <div className="absolute left-1/2 top-1/2 h-[520px] w-[520px] -translate-x-1/2 -translate-y-1/2 rounded-full border border-[rgba(255,107,0,0.35)] opacity-60" />
      </div>
      <Reveal className="relative mx-auto max-w-3xl px-5 text-center">
        <h2 id="final-cta" className="font-heading text-4xl font-bold leading-[1.08] tracking-tight text-white md:text-6xl">
          Your Content Deserves More Than Just a Cut.
        </h2>
        <p className="mx-auto mt-6 max-w-xl text-base leading-relaxed text-sub md:text-lg">
          Let’s turn your raw footage into short-form content that captures attention and communicates your message.
        </p>
        <a
          href="#contact"
          className="mt-10 inline-block rounded-md bg-brand px-9 py-4 text-sm font-semibold tracking-wide text-bg transition hover:bg-brand-2 hover:shadow-glow"
        >
          LET’S WORK TOGETHER ↗
        </a>
      </Reveal>
    </section>
  );
}
