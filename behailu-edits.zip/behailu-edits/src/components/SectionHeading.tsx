import type { ReactNode } from "react";

export default function SectionHeading({
  label,
  title,
  subtitle,
  align = "center",
  id,
}: {
  label?: string;
  title: ReactNode;
  subtitle?: string;
  align?: "center" | "left";
  id?: string;
}) {
  const center = align === "center";
  return (
    <div className={center ? "mx-auto max-w-3xl text-center" : "max-w-2xl"}>
      {label && (
        <p className="mb-4 font-body text-xs font-semibold uppercase tracking-[0.22em] text-brand">{label}</p>
      )}
      <h2
        id={id}
        className="font-heading text-3xl font-bold leading-[1.1] tracking-tight text-white sm:text-4xl md:text-5xl"
      >
        {title}
      </h2>
      {subtitle && <p className="mt-4 text-base leading-relaxed text-sub md:text-lg">{subtitle}</p>}
    </div>
  );
}
