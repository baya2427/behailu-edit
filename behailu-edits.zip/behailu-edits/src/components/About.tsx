"use client";

import { useState } from "react";
import { site } from "@/lib/site";
import Reveal from "./Reveal";
import SectionHeading from "./SectionHeading";

const paragraphs = [
  "Every second matters in short-form content. I focus on more than just cutting footage. I use storytelling, strategic pacing, visual emphasis, captions, and sound design to create videos that hold attention and communicate ideas clearly.",
  "My approach is simple: strengthen the hook, remove unnecessary moments, highlight important ideas, and keep viewers interested from the first second to the last.",
  "Whether you’re building a personal brand, educating an audience, or growing your business, I help transform your raw footage into polished content ready for social media.",
];

const focus = ["Strong hooks", "Strategic pacing", "Modern captions", "Sound design"];

export default function About() {
  const [photoFailed, setPhotoFailed] = useState(false);

  return (
    <section id="about" className="relative overflow-hidden py-24 md:py-32">
      <div aria-hidden className="pointer-events-none absolute -left-52 top-1/2 h-[640px] w-[640px] -translate-y-1/2 rounded-full bg-[radial-gradient(circle,rgba(255,107,0,0.38),transparent_68%)] blur-3xl" />

      <div className="relative mx-auto grid max-w-6xl items-center gap-14 px-5 lg:grid-cols-[minmax(0,5fr)_minmax(0,6fr)] lg:gap-20">
        <Reveal>
          <div className="relative mx-auto w-full max-w-[420px]">
            <div aria-hidden className="absolute -inset-3 rounded-[22px] border border-[rgba(255,107,0,0.35)]" />
            <div className="relative aspect-[4/5] overflow-hidden rounded-2xl border border-line bg-card">
              {photoFailed ? (
                <div className="flex h-full w-full items-center justify-center bg-gradient-to-br from-elevated to-bg">
                  <span className="font-heading text-8xl font-bold text-brand/80">B</span>
                </div>
              ) : (
                // Replace this image: save your photo as public/images/about.jpg
                // eslint-disable-next-line @next/next/no-img-element
                <img
                  src={site.aboutPhoto}
                  alt="Behailu at his editing workspace"
                  className="h-full w-full object-cover"
                  loading="lazy"
                  onError={() => setPhotoFailed(true)}
                />
              )}
              <div aria-hidden className="absolute inset-0 bg-gradient-to-t from-bg/70 via-transparent to-transparent" />
            </div>
          </div>
        </Reveal>

        <Reveal delay={0.1}>
          <SectionHeading
            align="left"
            label="About me"
            title="Turning Raw Footage Into Content That Connects."
          />
          <div className="mt-7 space-y-5 text-base leading-relaxed text-sub md:text-[17px]">
            {paragraphs.map((p) => (
              <p key={p}>{p}</p>
            ))}
          </div>
          <ul className="mt-8 flex flex-wrap gap-2.5">
            {focus.map((f) => (
              <li key={f} className="rounded-md border border-[rgba(255,107,0,0.35)] bg-card px-4 py-2 text-sm text-white">
                {f}
              </li>
            ))}
          </ul>
        </Reveal>
      </div>
    </section>
  );
}
