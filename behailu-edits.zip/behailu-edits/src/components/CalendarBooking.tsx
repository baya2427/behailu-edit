"use client";

import { CalendarCheck, Clock, Globe, Video } from "lucide-react";
import { useEffect, useState } from "react";
import { site } from "@/lib/site";
import Reveal from "./Reveal";
import SectionHeading from "./SectionHeading";

export default function CalendarBooking() {
  const [tz, setTz] = useState("");
  useEffect(() => setTz(Intl.DateTimeFormat().resolvedOptions().timeZone), []);

  const url = site.calendlyUrl;
  const embed = url
    ? `${url}${url.includes("?") ? "&" : "?"}hide_gdpr_banner=1&background_color=111111&text_color=ffffff&primary_color=ff6b00`
    : "";

  const details = [
    { icon: Clock, text: "20-minute discovery call" },
    { icon: Video, text: "Held on Google Meet" },
    { icon: CalendarCheck, text: "Automatic confirmation by email" },
    { icon: Globe, text: tz ? `Times shown in your timezone: ${tz}` : "Times shown in your local timezone" },
  ];

  return (
    <section id="booking" className="bg-surface py-24 md:py-32">
      <div className="mx-auto max-w-6xl px-5">
        <Reveal>
          <SectionHeading
            label="Book a call"
            title="Let’s Talk About Your Project."
            subtitle="Book a short discovery call so we can discuss your content, editing requirements, and expectations."
          />
        </Reveal>

        <div className="mt-14 grid gap-8 lg:grid-cols-[320px_minmax(0,1fr)]">
          <Reveal>
            <ul className="space-y-4 rounded-xl border border-line bg-card p-6">
              {details.map(({ icon: Icon, text }) => (
                <li key={text} className="flex items-start gap-3 text-sm text-sub">
                  <Icon size={18} className="mt-0.5 shrink-0 text-brand" />
                  {text}
                </li>
              ))}
              {url && (
                <li className="pt-2">
                  <a href={url} target="_blank" rel="noopener noreferrer" className="text-sm font-medium text-brand hover:text-brand-2">
                    Open scheduling page in a new tab ↗
                  </a>
                </li>
              )}
            </ul>
          </Reveal>

          <Reveal delay={0.1}>
            <div className="overflow-hidden rounded-xl border border-[rgba(255,107,0,0.35)] bg-card">
              {embed ? (
                <iframe
                  src={embed}
                  title="Book a discovery call on Calendly"
                  loading="lazy"
                  className="h-[720px] w-full border-0"
                />
              ) : (
                <div className="flex h-[360px] flex-col items-center justify-center gap-2 px-6 text-center">
                  <p className="font-heading text-lg font-semibold text-white">Scheduling not connected yet</p>
                  <p className="text-sm text-sub">Add your Calendly link as calendlyUrl in src/lib/site.ts.</p>
                </div>
              )}
            </div>
          </Reveal>
        </div>
      </div>
    </section>
  );
}
