export interface Service {
  icon: "clapperboard" | "video" | "podcast" | "user";
  title: string;
  description: string;
  service: string; // pre-selects this option in the inquiry form
}

export const services: Service[] = [
  {
    icon: "clapperboard",
    title: "Short-Form Video Editing",
    description:
      "Engaging Instagram Reels, TikTok videos, and YouTube Shorts with strong hooks, strategic pacing, captions, and visual storytelling.",
    service: "Individual Video Editing",
  },
  {
    icon: "video",
    title: "Talking-Head Editing",
    description:
      "Clean and professional talking-head videos enhanced with captions, B-roll, visual emphasis, and modern editing techniques.",
    service: "Talking-Head Editing",
  },
  {
    icon: "podcast",
    title: "Podcast Repurposing",
    description:
      "Transform long-form podcast conversations into engaging short clips that communicate powerful ideas and capture attention.",
    service: "Podcast Repurposing",
  },
  {
    icon: "user",
    title: "Personal Brand Content",
    description:
      "Consistent and polished video content that helps coaches, entrepreneurs, and personal brands communicate their message effectively.",
    service: "Personal Brand Content",
  },
];
