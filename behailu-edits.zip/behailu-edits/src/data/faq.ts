export const faqs = [
  {
    q: "What types of videos do you edit?",
    a: "I specialize in short-form content, including Instagram Reels, TikTok videos, YouTube Shorts, talking-head videos, and podcast clips.",
  },
  {
    q: "How long does video editing take?",
    a: "Delivery time depends on the length, complexity, and number of videos. I confirm the timeline before starting each project.",
  },
  {
    q: "Do you provide captions and subtitles?",
    a: "Yes. I can include professionally styled captions, subtitles, visual emphasis, and other editing enhancements.",
  },
  {
    q: "Can I request revisions?",
    a: "Yes. Agreed revisions are included according to the selected project or package.",
  },
  {
    q: "Can we work together monthly?",
    a: "Yes. I offer recurring editing arrangements for creators and brands that need consistent short-form content.",
  },
  {
    q: "How do I get started?",
    a: "Submit the project inquiry form and schedule a discovery call. We’ll discuss your requirements and agree on the next steps.",
  },
];
