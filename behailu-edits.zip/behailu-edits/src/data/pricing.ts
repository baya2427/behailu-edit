export interface Plan {
  name: string;
  tagline: string;
  features: string[];
  price: string;
  button: string;
  service: string; // pre-selects this option in the inquiry form
  highlighted?: boolean;
}

// Prices are "Custom quote" on purpose. Replace with real numbers when you are ready.
export const plans: Plan[] = [
  {
    name: "Starter",
    tagline: "For creators who need occasional short-form editing.",
    features: [
      "Individual video editing",
      "Professional captions",
      "Clean cuts and pacing",
      "Basic sound design",
      "Up to two agreed revisions",
    ],
    price: "Custom quote",
    button: "GET STARTED",
    service: "Individual Video Editing",
  },
  {
    name: "Creator",
    tagline: "For creators who need consistent monthly content.",
    features: [
      "8–12 short-form videos per month",
      "Professional captions",
      "B-roll and visual enhancements",
      "Consistent editing style",
      "Agreed monthly delivery schedule",
      "Up to two agreed revisions per video",
    ],
    price: "Custom quote",
    button: "CHOOSE CREATOR",
    service: "Monthly Short-Form Editing",
    highlighted: true,
  },
  {
    name: "Premium",
    tagline: "For established brands and businesses with larger content requirements.",
    features: [
      "16+ short-form videos per month",
      "Advanced editing",
      "Custom motion graphics",
      "Priority scheduling",
      "Consistent content production",
      "Ongoing collaboration",
    ],
    price: "Custom quote",
    button: "DISCUSS YOUR PROJECT",
    service: "Monthly Short-Form Editing",
  },
];
