export interface Testimonial {
  name: string;
  role: string;
  text: string;
  image?: string; // e.g. "/images/testimonials/name.jpg"
}

// Add only real testimonials from real clients. While this list is empty,
// the whole "What Clients Say" section stays hidden on the site.
//
// Example:
//   { name: "Client Name", role: "Their role, company", text: "What they said.", image: "/images/testimonials/client.jpg" },
export const testimonials: Testimonial[] = [];
