// ─────────────────────────────────────────────────────────────────────────────
// PORTFOLIO CONTENT — edit this file to add, remove or replace videos.
//
// To add a real video, add an object like this to the `portfolio` array:
//
//   {
//     id: "th-hook-breakdown",              // unique, no spaces
//     title: "Hook breakdown for a coach",  // shown on the card
//     category: "talking-head",             // one of the category ids below
//     thumbnail: "/images/portfolio/th-hook-breakdown.webp", // 9:16 WebP in public/images/portfolio
//     videoUrl: "/videos/th-hook-breakdown.mp4",             // MP4 in public/videos, or a Vimeo / YouTube link
//     description: "Short line shown under the video.",
//     featured: true,                       // optional
//   },
//
// Then delete the matching placeholder line (the `...slots(...)` line) for that
// category once you have added all of its real videos. Items appear in the order listed.
// ─────────────────────────────────────────────────────────────────────────────

export type CategoryId =
  | "talking-head"
  | "personal-brand"
  | "educational"
  | "podcast"
  | "cinematic"
  | "social";

export interface PortfolioCategory {
  id: CategoryId;
  title: string;
  description: string;
}

export interface PortfolioItem {
  id: string;
  title: string;
  category: CategoryId;
  thumbnail: string; // "" shows a placeholder
  videoUrl: string; // "" shows an "add your video" message in the player
  description?: string;
  featured?: boolean;
}

export const categories: PortfolioCategory[] = [
  {
    id: "talking-head",
    title: "Talking-Head Videos",
    description: "Clean, confident edits with sharp cuts, captions and visual emphasis.",
  },
  {
    id: "personal-brand",
    title: "Personal Brand Content",
    description: "Consistent content that gives coaches and founders a recognizable voice.",
  },
  {
    id: "educational",
    title: "Educational Reels",
    description: "Complex ideas, paced and illustrated so they stay easy to follow.",
  },
  {
    id: "podcast",
    title: "Podcast Clips",
    description: "The strongest moments of long conversations, turned into standalone shorts.",
  },
  {
    id: "cinematic",
    title: "Cinematic Short-Form Videos",
    description: "Story-led edits with mood, color and sound design.",
  },
  {
    id: "social",
    title: "Social Media Content",
    description: "Scroll-stopping edits for Reels, TikTok and YouTube Shorts.",
  },
];

// Placeholder slots so every carousel has cards until real videos are added.
const slots = (category: CategoryId, count = 6): PortfolioItem[] =>
  Array.from({ length: count }, (_, i) => ({
    id: `${category}-slot-${i + 1}`,
    title: `Video ${String(i + 1).padStart(2, "0")}`,
    category,
    thumbnail: "",
    videoUrl: "",
    description: "Placeholder. Replace this item in src/data/portfolio.ts.",
  }));

export const portfolio: PortfolioItem[] = [
  // Talking-Head Videos
  ...slots("talking-head"),
  // Personal Brand Content
  ...slots("personal-brand"),
  // Educational Reels
  ...slots("educational"),
  // Podcast Clips
  ...slots("podcast"),
  // Cinematic Short-Form Videos
  ...slots("cinematic"),
  // Social Media Content
  ...slots("social"),
];
