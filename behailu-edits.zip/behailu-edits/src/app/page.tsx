import About from "@/components/About";
import CalendarBooking from "@/components/CalendarBooking";
import FAQ from "@/components/FAQ";
import FinalCTA from "@/components/FinalCTA";
import Footer from "@/components/Footer";
import Hero from "@/components/Hero";
import Navbar from "@/components/Navbar";
import Portfolio from "@/components/Portfolio";
import Pricing from "@/components/Pricing";
import Process from "@/components/Process";
import Services from "@/components/Services";
import Testimonials from "@/components/Testimonials";
import BookingForm from "@/components/BookingForm";
import TrustStrip from "@/components/TrustStrip";

export default function Home() {
  return (
    <>
      <Navbar />
      <main>
        <Hero />
        <TrustStrip />
        <About />
        <Portfolio />
        <Services />
        <Process />
        <Pricing />
        <Testimonials />
        <BookingForm />
        <CalendarBooking />
        <FAQ />
        <FinalCTA />
      </main>
      <Footer />
    </>
  );
}
