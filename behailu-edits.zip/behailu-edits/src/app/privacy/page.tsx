import type { Metadata } from "next";
import LegalPage from "@/components/LegalPage";
import { site } from "@/lib/site";

export const metadata: Metadata = { title: "Privacy Policy | Behailu.edits" };

export default function Privacy() {
  return (
    <LegalPage title="Privacy Policy">
      <p className="rounded-md border border-line bg-card p-4 text-sm">
        Draft template: review and edit this text so it matches how you actually work before relying on it.
      </p>
      <p>When you send a project inquiry, the details you enter (name, email, project information and links) are sent to me through Formspree so I can reply to you. I use them only to respond to your inquiry and discuss your project.</p>
      <p>If you book a discovery call, scheduling is handled by Calendly under its own privacy policy.</p>
      <p>I do not sell your information. To ask me to delete your inquiry, email {site.email}.</p>
    </LegalPage>
  );
}
