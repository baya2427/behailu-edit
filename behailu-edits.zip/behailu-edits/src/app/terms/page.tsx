import type { Metadata } from "next";
import LegalPage from "@/components/LegalPage";
import { site } from "@/lib/site";

export const metadata: Metadata = { title: "Terms of Service | Behailu.edits" };

export default function Terms() {
  return (
    <LegalPage title="Terms of Service">
      <p className="rounded-md border border-line bg-card p-4 text-sm">
        Draft template: review and edit this text so it matches your real working terms before relying on it.
      </p>
      <p>This website presents the short-form video editing services offered by Behailu.edits. Submitting an inquiry or booking a call does not create a binding agreement.</p>
      <p>Project scope, pricing, timelines, revisions and delivery are agreed with you before work begins. Footage and materials you provide remain yours.</p>
      <p>Questions about these terms: {site.email}.</p>
    </LegalPage>
  );
}
