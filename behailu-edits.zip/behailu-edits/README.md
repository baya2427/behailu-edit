# Behailu.edits — studio website

Next.js (App Router) · TypeScript · Tailwind · Framer Motion · React Hook Form · Zod

## Run locally
```
npm install
npm run dev        # http://localhost:3000
```

## Deploy (same workflow as before)
GitHub Desktop → push to GitHub → Vercel auto-deploys.
On Vercel: Project → Settings → Environment Variables, add `NEXT_PUBLIC_FORMSPREE_ID`, then redeploy.

## Things you must do before going live
1. **Formspree** – create a form at formspree.io, copy the ID (the part after `/f/`), and set `NEXT_PUBLIC_FORMSPREE_ID`
   (in `.env.local` for local work, and in Vercel). Until it is set, the form shows an honest "not connected" message
   and does NOT pretend to send.
2. **Calendly** – `src/lib/site.ts` uses `https://calendly.com/behailumitiku03`. Change it to the link of your 20-minute
   event (e.g. `.../20min`) so visitors land straight on it. Make sure the event uses Google Meet.
3. **Your photo** – save it as `public/images/about.jpg` (portrait, roughly 4:5).
4. **Your videos** – see below.

## Adding portfolio videos
All content lives in `src/data/portfolio.ts` (instructions at the top of that file).
- Thumbnails: 9:16 WebP in `public/images/portfolio/` (e.g. 540×960)
- Videos: MP4 in `public/videos/`, or paste a Vimeo / YouTube link as `videoUrl`
- Each category is its own carousel. Delete the placeholder `...slots(...)` line for a category once it has real items.

## Other editable content
- Brand, email, socials, hero reel: `src/lib/site.ts`
- Services / pricing / FAQ / testimonials: `src/data/*.ts` (pricing is "Custom quote"; the testimonials section stays hidden until you add real ones)
- Colors: `tailwind.config.ts`
- Privacy and Terms pages (`src/app/privacy`, `src/app/terms`) are draft templates — review them.
